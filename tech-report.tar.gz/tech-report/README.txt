UNIX/Linux: type 'make' to build the paper.pdf file.
Windows: use a Latex editor (e.g. WinEdt) to build the paper.pdf